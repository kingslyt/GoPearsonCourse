package main

import "fmt"

func main() {
	sum := 0
	for {
		sum++ // repeated forever
	}

	fmt.Println(sum)
}
