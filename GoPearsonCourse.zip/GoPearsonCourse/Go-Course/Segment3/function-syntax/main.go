package main

import "fmt"

func name(yourName string) string {

	fmt.Println("Returning Name")

	return yourName

}
