package main

import "fmt"

func main() {
	fmt.Println("standard and built-in")
}
