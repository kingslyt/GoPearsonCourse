`go get library_name`

Init mod
`go mod init package`

Tidy
`go mod tidy`