package main

import "fmt"

func main() {
	yourName := "Mike"

	fmt.Println((&yourName))

	fmt.Println(yourName)
}
