package main

import "fmt"

func main() {
	combine("Mike", 30)
}

func combine(name string, age int) {
	// fmt.Println(name + " is " + age + " years old")
	fmt.Println(name)
	fmt.Println(age)
}
