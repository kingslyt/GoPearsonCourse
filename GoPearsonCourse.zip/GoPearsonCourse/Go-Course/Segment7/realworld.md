## Apps

Using two different apps:
- Go web API (https://github.com/AdminTurnedDevOps/GoWebAPI)
- ORM Builder (https://github.com/AdminTurnedDevOps/gorm-demo)