package main

import "fmt"

func main() {
	var sayhi string = "hello world"
	fmt.Println(sayhi)
}
