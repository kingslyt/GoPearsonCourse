// Short declaration

package main

import "fmt"

func main() {
	sayhi := "hello world"
	fmt.Println(sayhi)
}
