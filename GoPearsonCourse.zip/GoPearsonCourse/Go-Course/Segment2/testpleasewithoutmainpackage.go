package wontwork

import "fmt"

func main() {
	fmt.Println("Uh oh")
}
