package main

import "fmt"

func main() {
	testing()
}

func testing() {
	fmt.Println("hello from the testing function")
}
