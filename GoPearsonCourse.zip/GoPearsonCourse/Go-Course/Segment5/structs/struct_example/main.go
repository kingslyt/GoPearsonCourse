





					type car struct {
						make       string
						model      string
						wheel_size int
						color      string
						quantity   int
					}