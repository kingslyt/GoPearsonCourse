package main

import "fmt"

func main() {

	// coffeeShops := make(map[string]int)

	// coffeeShops["paramus"] = 4
	// coffeeShops["saddle brook"] = 6

	// OR

	moreCoffeeShops := map[string]int{
		"paramus":      4,
		"saddle brook": 6,
	}

	// fmt.Println(coffeeShops)
	fmt.Println(moreCoffeeShops)

}
